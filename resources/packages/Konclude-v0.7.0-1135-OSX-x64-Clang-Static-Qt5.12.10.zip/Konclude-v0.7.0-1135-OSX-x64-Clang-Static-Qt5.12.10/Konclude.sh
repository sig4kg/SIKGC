#!/bin/bash
./Binaries/Konclude $*